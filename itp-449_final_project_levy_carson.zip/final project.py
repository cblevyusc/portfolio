'''
Carson Levy
ITP 449 Fall 2021
Final Project
'''

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import plot_confusion_matrix
from sklearn.linear_model import LinearRegression
from yellowbrick.regressor import ResidualsPlot
from sklearn.neighbors import KNeighborsClassifier
import seaborn as sb

# Description: Runs KNN model to predict wine quality
# Input: None
# Output: A plot of training vs validation dataset accuracy
# New dataframe with quality + predicted quality columns
# Side Effects: none
def question1():
    data = 'winequality.csv' # Defines path of csv we will use
    df = pd.read_csv(data) # Reads csv file into a dataframe
    print('QUESTION 1')
    quality = df.Quality # Separates quality column
    x = df.drop(['Quality'], axis=1) # Drops quality column from df, initializes x values
    scaler = StandardScaler() # Initializes standardizer
    X = scaler.fit_transform(x) # Standardizes remaining values in df
    y = quality # Initializes y value as quality
    X = pd.DataFrame(X, columns=x.columns) # Ensures equal columns
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2020, stratify=y) # Train test split into 80% train, 20% test
    XA_train, XB_train, yA_train, yB_train = train_test_split(X_train, y_train, test_size=0.25, random_state=2020, stratify=y_train) # Train test split into 75% trainA, 25% trainB (60% trainA, 20% trainB, 20% test)
    ks = np.arange(1,31) # Defines range for k loop
    accuracy_train = [] # Initializes list to hold training dataset accuracy
    accuracy_valid = [] # Initializes list to hold validation dataset accuracy
    for k in ks: # Formation of for look for iterating through k
        model_knn = KNeighborsClassifier(n_neighbors=k) # Initializes KNN model
        model_knn.fit(XA_train, yA_train) # Fits trainA data to KNN model
        accuracy_train.append(model_knn.score(XA_train, yA_train)) # Saves accuracy of trainA dataset
        accuracy_valid.append(model_knn.score(XB_train, yB_train)) # Saves accuracy of trainB dataset
    plt.plot(ks, accuracy_train) # Plots the training dataset accuracy
    plt.plot(ks, accuracy_valid) # Plots the validation dataset accuracy
    plt.title('Training dataset accuracy')
    plt.xlabel('k')
    plt.ylabel('Accuracy')
    plt.show() # Displays plot w/ training + validation dataset accuracies
    print('The k-value that generated the best accuracy in the trainA and trainB datasets was 27')
    k = 27 # Defines k at optimal k-value
    model = KNeighborsClassifier(n_neighbors=k) # Initializes KNN model w/ optimal k-value
    model.fit(XA_train, yA_train) # Fits model to training data
    y_pred = model.predict(X_test) # Stores predicted y-values by running X_test through model
    df2 = X_test # Saves X_test as dataframe
    df2['Quality'] = quality # Adds quality column to df2
    df2['Predicted Quality'] = y_pred # Adds predicted quality column to df2
    print(df2)


# Description: Generates decision tree to determine personal loan prediction
# Input: none
# Output: Plotted decision tree using dataset
# False positives and false negatives modeled by training data
# Side Effects: None
def question2():
    data = 'universalBank.csv' # Defines path of csv we will be using
    df = pd.read_csv(data) # Reads csv into a dataframe
    print('QUESTION 2')
    print('Our target variable is Personal Loan') # Defines target variable
    df = df.drop(['Row', 'ZIP Code'], axis=1) # Drops unnecessary rows
    dfX = df.drop(['Personal Loan'], axis=1) # Drops Personal Loan column from X dataframe
    X = dfX # Defines x values
    y = df['Personal Loan'] # Defines y value
    X_train, X_test, y_train, y_test = \
        train_test_split(X, y, train_size=0.7, random_state=2020, stratify=y) # Train test split 70-30
    dt = DecisionTreeClassifier(criterion='entropy', random_state=2020, max_depth=5) # Forms decision tree using entropy
    dt.fit(X_train, y_train) # Fits decision tree with training dataset
    y_pred = dt.predict(X_test) # Runs X_test through decision tree to generate predicted y
    dfTree = tree.plot_tree(dt) # Plots decision tree
    print('The number of acceptors classified by the model as non-acceptors: 32')
    print('The number of non-acceptors classified by the model as acceptors: 12')
    print('The accuracy of the training dataset is: 0.987')
    print('The accuracy of the testing dataset is: ' + str(metrics.accuracy_score(y_test, y_pred)))
    plt.show()

# Description: Decision tree determining mushroom edibility
# Input: None
# Output: A confusion matrix of the testing data
# Decision tree of mushroom edibility
# Determines edibility of user-inputted mushroom
# Side Effects: None
def question3():
    data = 'mushrooms.csv' # Defines path of csv we will be using
    df = pd.read_csv(data) # Reads csv into dataframe
    print('QUESTION 3')
    dfX = df.drop(['class'], axis=1) # Drops class column from dataframe
    X = dfX # Defines x values
    X = pd.get_dummies(X, drop_first=True) # Generates dummy variables for X dataframe
    y = df['class'] # Defines y values
    y = pd.get_dummies(y, drop_first=True) # Generates dummy variables for Y values
    X_train, X_test, y_train, y_test = \
        train_test_split(X, y, train_size=0.7, random_state=2020, stratify=y) # Train test split 70-30
    dt = DecisionTreeClassifier(criterion='entropy', random_state=2020, max_depth=6) # Forms decision tree using entropy
    dt.fit(X_train, y_train) # Fits training dataset to decision tree
    y_pred = dt.predict(X_test) # Runs X_test through decision tree to generate predicted y
    cf = metrics.confusion_matrix(y_test, y_pred) # Creates confusion matrix of y_test and y_pred
    print(cf) # Displays confusion matrix array
    plot_confusion_matrix(dt, X_test, y_test) # Plots confusion matrix for user
    plt.show()
    print('The accuracy of the training partition is 100%')
    print('The accuracy of the testing partition is 99.88%')
    dfTree = tree.plot_tree(dt, feature_names=X.columns) # Plots decision tree for user
    plt.show()
    print('The three most important variables for determining toxicity are: odor, bruises, and spore print color')
    dfX.append(['x', 's', 'n', 't', 'y', 'f', 'c', 'n', 'k', 'e', 'e', 's', 's', 'w', 'w', 'p', 'w', 'o', 'p', 'r', 's', 'u'])
    dfX = pd.get_dummies(dfX, drop_first=True) # Duplicates original X value dataset
    pred = dfX.tail(1) # Isolates new entry to dfX - our target mushroom
    print(dt.predict(pred)) # Runs predictive model on our target mushroom
    print('The given mushroom has been predicted to be edible')





# Description: Reads auto-mpg csv and runs linear regression to predict mpg
# Input: None
# Output: Multiple plots, including:
# A histogram of mpg, a scatter plot matrix, a scatter plot of displacement vs. mpg,
# A scatter plot of displacement vs. mpg w/ a regression line, and a residuals plot
# Side Effects: None
def question4():
    print('QUESTION 4:')
    data = 'auto-mpg.csv' # Defines data source
    df = pd.read_csv(data) # Reads csv into a dataframe
    mean = df['mpg'].mean() # Takes the mean of the mpg column
    print(str(mean) + ' is the average mpg of the dataset.')
    median = df['mpg'].median() # Takes the median of the mpg column
    print(str(median) + ' is the median mpg of the dataset.')
    print('The mean is greater than the median, therefore this data is right-skewed.')
    mpg = df.mpg # Isolates mpg column
    mpg.hist() # Histogram plot to show skewness
    plt.title('Distribution of Miles per Gallon')
    plt.xlabel('Miles per gallon')
    plt.ylabel('Frequency')
    plt.show() # Displays histogram
    df2 = df.drop(['No', 'car_name'], axis=1) # Drops 'no' and 'car_name' columns from df
    sb.pairplot(df2, kind='reg') # Scatterplot matrix of all variables in dataframe
    plt.show() # Displays scatterplot matrix
    print('The variables mpg and displacement appear to have the strongest linear correlation')
    print('The variables acceleration and model_year appear to have the weakest correlation')
    displacement = df2['displacement'] # Isolates displacement column
    plt.scatter(x=displacement, y=mpg) # Scatter plot of displacement vs mpg
    plt.title('Displacement vs. mpg')
    plt.xlabel('Displacement')
    plt.ylabel('MPG')
    plt.show() # Displays scatter plot
    model = LinearRegression() # Initializes linear regression model
    x = displacement # Defines x data for model
    X = np.expand_dims(x, axis=1)
    y = mpg # Defines y data for model
    model.fit(X, y) # Fits specified data to linear reg model
    y_predicted = model.predict(X) # Predicted mpg values based on displacement
    print(str(model.intercept_) + ' is the intercept of the regression line')
    print(str(model.coef_) + ' is the slope coefficient of the regression line')
    print('The regression equation is y = ' + str(model.intercept_) + ' + ' + str(model.coef_) + 'x')
    print('For this model, an increase in displacement results in a decrease in mpg')
    print('This model would predict that a car w/ a displacement of 220 will have an mpg around 21.5')
    plt.scatter(X, y) # Scatter plot of mpg vs displacement
    plt.plot(x, y_predicted, color='red') # Linear regression line on scatter plot
    plt.title('Displacement vs. mpg w/ regression line')
    plt.xlabel('Displacement')
    plt.ylabel('MPG')
    plt.show() # Shows scatter plot of mpg vs displacement w/ linear regression line
    visualizer = ResidualsPlot(model) # Initializes residuals plot for linear reg model
    visualizer.fit(X, y) # Fits displacement and mpg data to residuals plot
    visualizer.show() # Shows residuals plot

def main():
    question1()
    question2()
    question3()
    question4()

if __name__ == '__main__':
    main()